from flask import Flask,render_template


app=Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/student')
def student():
    return render_template('student_login.html')
@app.route('/teacher')
def teacher():
    return render_template('teacher_login.html')


if __name__ == '__main__':
    app.run()
